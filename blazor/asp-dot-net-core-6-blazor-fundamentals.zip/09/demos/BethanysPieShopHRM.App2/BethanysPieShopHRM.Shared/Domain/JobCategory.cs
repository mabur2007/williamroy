﻿namespace BethanysPieShopHRM.Shared.Domain
{
    public class JobCategory
    {
        public int JobCategoryId { get; set; }
        public string JobCategoryName { get; set; } = string.Empty;
    }
}
