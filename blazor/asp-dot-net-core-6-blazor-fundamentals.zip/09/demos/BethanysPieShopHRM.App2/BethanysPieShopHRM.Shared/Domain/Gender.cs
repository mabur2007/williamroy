﻿namespace BethanysPieShopHRM.Shared.Domain
{
    public enum Gender
    {
        Male,
        Female,
        Other
    }
}
