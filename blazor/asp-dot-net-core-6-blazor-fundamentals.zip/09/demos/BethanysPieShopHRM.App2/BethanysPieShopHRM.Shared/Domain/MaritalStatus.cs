﻿namespace BethanysPieShopHRM.Shared.Domain
{
    public enum MaritalStatus
    {
        Married,
        Single,
        Other
    }
}