﻿namespace BethanysPieShopHRM.App
{
    public class ApplicationState
    {
        public int NumberOfMessages { get; set; } = 0;
    }
}
