﻿namespace BethanysPieShopHRM.App.Helper
{
    public class LocalStorageConstants
    {
        public const string EmployeesListExpirationKey = "EmployeesListExpiration";
        public const string EmployeesListKey = "EmployeesList";
    }
}
