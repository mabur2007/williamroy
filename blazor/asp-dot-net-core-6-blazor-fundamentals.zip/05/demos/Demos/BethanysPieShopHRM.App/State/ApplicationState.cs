﻿namespace BethanysPieShopHRM.App.State
{
    public class ApplicationState
    {
        public int NumberOfMessages { get; set; } = 0;
    }
}
